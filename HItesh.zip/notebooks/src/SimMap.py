import pandas as pd
#import pymysql
import os
import numpy as np
import re
import itertools
from sklearn.feature_extraction.text import CountVectorizer
from collections import Counter
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.pipeline import Pipeline
from nltk.stem import PorterStemmer, WordNetLemmatizer
from sklearn.neighbors import NearestNeighbors
from nltk import word_tokenize
import nltk
from joblib import Parallel, delayed
import pickle
import nltk

def calc_similarity_rowwise(df, col1, col2):
    """
        Function that calculates the cosine similarty between 2 columns of a dataframe. 
    """
    sims = list()
    for row in df[[col1, col2]].iterrows():
        r = row[1]
        sims.append(np.min(get_cosine_sim(r.col1, r.col2)))
    
    return sims

def get_cosine_sim(*strs):
    """
        Calculate the similartity of a given number of input strings passed.
        If only emptx strings are passed than nan is returned.
        
        Example: 
            string_1 = "heLLo World"
            string_2 = "Hello world 123"
            get_cosine_sim(string_1, string_2)
    """
    
    if not np.max([word.strip() == "" for word in strs]):
        vectors = [t for t in get_vectors(*strs)]

        return cosine_similarity(vectors)
    else:
        return np.nan
    
def get_vectors(*strs):
    """
        Helper function for performing tf-idf vectorization of input strings
    """
    text = [t for t in strs]
    if np.max([len(word.strip()) for word in text]) > 0:
        vectorizer = TfidfVectorizer(text)
        return vectorizer.fit_transform(text).toarray()
    else:
         pass 
        
def text_col_builder(df, text_cols):
        df['text'] = df[text_cols].apply(lambda x: ' '.join(x.dropna().astype(str)),axis=1)
        return df
    
    
class ColumnExtractor(BaseEstimator, TransformerMixin):
    """
        Base class. Defines which column to select and in which to store results
        text_col = Input column of dataframe with string to be preprocessed
        out_col = Output column of dataframe where the preprocessed column is stored
    """
    def __init__(self, text_col, out_col):
        self.text_col = text_col
        self.out_col  = out_col
    def fit(self, X, y = None):
        return self
    def transform(self, X):
        return self

class PatternCleaner(ColumnExtractor):
    """
        Cleans input col from specified pattern. Inherits fit from base ColumnExtractor.
        
        Input: 
        text_col = Input column of dataframe with string to be preprocessed
        out_col = Output column of dataframe where the preprocessed column is stored
        pattern = regex with patttern to replace
    """
    def __init__(self, text_col,out_col, pattern = None):       
        super().__init__(text_col, out_col)
        self.pattern = pattern
   
    def transform(self, X):
        X[self.out_col] = (
            X[self.text_col]
            .apply(lambda x: x if type(x)!=str else re.sub(self.pattern, " " ,x))
            .apply(lambda x: x if type(x)!=str else re.sub("\s+"," " ,x))
            .apply(lambda x: x if type(x)!=str else x.lower())
            )
        
        return X

class WordCutter(ColumnExtractor):
    """
        Cleans input col from tokens under a certain length. Inherits fit from base ColumnExtractor.
        
        Input: 
        text_col = Input column of dataframe with string to be preprocessed
        out_col = Output column of dataframe where the preprocessed column is stored
        min_length = minimum length to be kept.
       
    """
    
    def __init__(self, text_col,out_col, min_length):       
        super().__init__(text_col, out_col)
        self.min_length = min_length
   
    def transform(self, X):
        X[self.out_col] = X[self.text_col].apply(lambda x: str(x) if type(x)!=str else ' '.join([word for word in x.split() if len(word) >= self.min_length ]))
        return X

class DataFrameSelector(BaseEstimator, TransformerMixin):
    """
        Selects Dataframe column and returns its values as numpy array. Important when scikitlearn algorithms are applied.
        
        Input: 
        attribute_names =  Input column of dataframe with string to be preprocessed       
    """
    def __init__(self, attribute_names):
        self.attribute_names = attribute_names
            
    def fit(self, X, y=None):
        return self
    def transform(self,X):
        #print("The folollowing columns are transformed to numpy arrays:" + str(attribute_names) )
        return X[self.attribute_names].values


class StopwordRemover(ColumnExtractor):
    """
        Cleans input col from tokens in a particular stopword list. Inherits fit from base ColumnExtractor.
        
        Input: 
        text_col = Input column of dataframe with string to be preprocessed
        out_col = Output column of dataframe where the preprocessed column is stored
        stop_list = list of stopwords
       
    """
    def __init__(self, text_col,out_col, stop_list):
        super().__init__(text_col, out_col)
        self.stop_list = stop_list   
   
    def transform(self, X):
        X[self.out_col] = X[self.text_col].apply(lambda x: str(x) if type(x)!=str else ' '.join([word for word in x.split() if word not in self.stop_list]))
        return X
    
class LemmaTokenizer(object):
    """
        User specific tokenizer to be used in in scikit learn tf-idf or countvectorizer class. Performs Porter-stemming and word
        tokenization from nltk
    """
    
    def __init__(self):
        self.ps = PorterStemmer()
    def __call__(self, doc):
        return [self.ps.stem(word) for word in word_tokenize(doc)]
    
    
    
def bag_of_words(df, dict_mode, analyzer = None,ngram_range = None,  pattern = "[^\w.+-]", stop_words = None):
    """
        Main function to calc similarity based on a list of cols to consider
    """
   
    # print("Starting preprocessing")
    dict_X = dict()
    
    if analyzer: 
        if type(analyzer) != dict:
            print("Please provide a dictionary for analyzing.")
    
    if not ngram_range:
        ngram_range = [(1,1) for key in dict_mode.keys()]
    k = 0
    for mode,cols_to_consider in dict_mode.items():
        if cols_to_consider == []:
            continue
        else: 
            df_tmp = df[cols_to_consider]
            df_tmp = text_col_builder(df_tmp, cols_to_consider)

            cleaner_text = PatternCleaner(text_col="text", out_col="text_cleaned", pattern = pattern)
            cutter_text = WordCutter(text_col="text_cleaned", out_col="text_cleaned", min_length=1)
            #if stop_words: 
            #    stopwords_remover_text = StopwordRemover(text_col="text_cleaned", out_col="text_cleaned", stop_list=stop_words)
            pipe_prep_text = Pipeline([("cleaner_text", cleaner_text),
                                  ("cutter_text",  cutter_text),
                                #  ("stopwords_remover_text", stopwords_remover_text)
                                 ])

            data_final = pipe_prep_text.fit_transform(df_tmp)

            selector_text = DataFrameSelector("text_cleaned")

            if analyzer[mode]: 
                tf_idf_text = TfidfVectorizer(stop_words=stop_words,
                                     analyzer=analyzer[mode],
                                     ngram_range= ngram_range[k],
                                     lowercase=True)
            else: 
                tf_idf_text = TfidfVectorizer(
                                     stop_words = stop_words,
                                     ngram_range = ngram_range[k],
                                     tokenizer = LemmaTokenizer(),
                                     lowercase = True)

            pipe_tfidf_text = Pipeline([ ("selector", selector_text),("tf_idf", tf_idf_text)])
            dict_X[mode] = pipe_tfidf_text.fit_transform(data_final)
            print("-------------------------------" + mode[0] + "_" + mode[1]  + " preprocessed successfully -------------------------------------")
            k += 1
  #  print("--------------------------------------- preprocessed successfully ---------------------------------------------")
    return dict_X


def cosine_sim_mp(dict_X,
                  df,
                  cat = None, 
                  n_neighbors = 200,
                  threshold = 0.7,
                 metric = 'cosine'):
    #time.sleep(0.001)
    """
        calculates based on sparse/dense (tf-idf) - matrix the cosine distance between every material. The n_neighbors that are closest
        are then taken from the input dataframe and are saved into a dictionary. The output dictionary will have as key the corresponding 
        index from the dataframe and additionally the n_neighbors from the dataframe. So the values of the dictionary are the 
        dataframes of lenght n_neighbors
        
        Input: 
            dict_X = dict of tf idf sparse matrices
            df = pandas dataframe from which the n_neigbors - closest row items are chosen for index k
            resukltpath = path tpo store the results to
            cat = (optional) category path
            n_neighbors = number of neighbors 
            threshold minimum similarity required to be considered
    """
    
    similarities = dict()
    if "OVERALL" not in dict_X.keys():
        return pd.DataFrame()
    else: 
        X = dict_X["OVERALL"]
    
        model_knn = NearestNeighbors(n_neighbors= n_neighbors, metric = metric, n_jobs=-1)

        model_knn.fit(X)
        distances, indices = model_knn.kneighbors(X, n_neighbors=n_neighbors)
    # Check type, is X numpy or sparse matrix?

        if not cat: 
            cat = 'all_parts'

        threshold = 1 - threshold
        
        for k in range(indices.shape[0]):
            df_tmp = pd.DataFrame()
            most_sim = [idx for (i,idx) in enumerate(indices[k]) if distances[k,i] < threshold]
            #print(most_sim)
            key_main = df.index[k]
            df_tmp["PART_ID_1"] = np.repeat(key_main, len(most_sim))
            df_tmp["PART_ID_2"] = df.index[most_sim]
            df_tmp['CATEGORY'] = np.repeat(cat, len(most_sim))
           # df_tmp['DESCRIPTION'] = np.repeat(np.nan, len(most_sim))
            df_tmp["OVERALL_SIMILARITY"] = np.round(1 - distances[k,:len(most_sim)],4) 
            # calculate the corresponding form fit function attributes to the relevant indices
            for key, X in dict_X.items():
                if key != "OVERALL":
                    
                    tmp = (X[k,] * X.T).toarray().flatten()
                    # Different weightening based on importance. H means 100% accounts to similarity score. 
                    # M only 50%
                    cos_dist = np.round(tmp / np.max(tmp),4)
                   
                    df_tmp[key[0].upper() + "_" + key[1] + "_SIMILARITY"] = cos_dist[most_sim]
                else: 
                    continue

            # print(df_tmp)
            mode = ['FIT', 'FORM', 'FUNCTION']
            for modus in mode: 
                cols = [col for col in df_tmp.columns if modus in col]
                if cols == []:
                    continue
                   
                elif len(cols) > 1:
                    df_tmp[modus + "_SIMILARITY"] = (df_tmp[modus + "_H_SIMILARITY"] + df_tmp[modus + "_M_SIMILARITY"] * 0.5) / 1.5
                    df_tmp.drop(columns = cols, inplace = True)
                else: 
                    df_tmp[modus + "_SIMILARITY"] = df_tmp[cols[0]]
                    df_tmp.drop(columns = cols, inplace = True)
            similarities[key_main] = df_tmp

  
        df_sim_map = pd.concat(similarities, ignore_index=True)

        df_sim_map.to_csv('/S3/FILES_MT_S3/' + cat + "_new.csv", index = False, sep = "|")
        
    return df_sim_map



def calc_similarity(att_dict,dict_X,df_per_cat, analyzer, cat,stop_words ):

    print("--------------------- Starting Preprocess for " + cat + " ---------------------")
  #  start = time()

    dict_X[cat] = bag_of_words(df_per_cat[cat],
                         att_dict[cat],
                         analyzer = analyzer ,
                         ngram_range = None,
                         pattern = "[^\w\.+\-\%]",
                         stop_words = stop_words)

    df = df_per_cat[cat]
    #text_cols = att_dict[cat]["OVERALL"]

    return cosine_sim_mp(dict_X[cat],
                  df,
                  cat = cat.replace("/", " "), 
                  n_neighbors = min(100,df.shape[0]),
                  threshold = 0.7,
                  metric = 'cosine')