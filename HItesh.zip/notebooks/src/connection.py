import MySQLdb
from sqlalchemy import create_engine

def set_connection(port, dbnames = None, max_overflow = 20):
   
    # General connection to MYSQL Database    
    host='127.0.0.1'
    user="matspeclogin"
    password="matspecpasswd213"
    
    if dbnames: 
        #dbnames = ["matspec_tmp", "matspec_attribute"]

        mysql_connection = dict()
        engines = dict()
        for db in dbnames:
            mysql_connection[db] = "mysql+mysqldb://" + user + ":" + password + "@" + host + ":" + str(port) + "/" + db    
            engines[db] = create_engine(mysql_connection[db], max_overflow = max_overflow)
   
    return engines