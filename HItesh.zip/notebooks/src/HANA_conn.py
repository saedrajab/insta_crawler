import os
import sys
# Add source script to read data from Hana
sys.path.append('/home/Z000SYPA/hana-r-python-connecticity/python/')

# User and password definition
user = ("%s" % os.popen('/opt/parameter-get user').read()).rstrip('\n')

password_eh0 = ("%s" % os.popen('/opt/parameter-get password_eh0').read()).rstrip('\n')
password_eh0

import os
import sys
from py2hana import *

# Add source script to read data from Hana
#sys.path.append('home/Z000SYPA/opt/repos/hana-r-python-connecticity/python/')

# User and password definition
user = ("%s" % os.popen('/opt/parameter-get user').read()).rstrip('\n')

password_eh0 = ("%s" % os.popen('/opt/parameter-get password_eh0').read()).rstrip('\n')
#password_ehq = ("%s" % os.popen('/opt/parameter-get password_ehq').read()).rstrip('\n')
#password_eh1 = ("%s" % os.popen('/opt/parameter-get password_eh1').read()).rstrip('\n')

# Read parameters
main_url_eh0 = 'https://hanadatalake-eh0.siemens.com/siemens/MATSPEC/AWS/'
main_url_ehq = 'https://hanadatalake-ehq.siemens.com/siemens/MATSPEC/AWS/'
main_url_eh1 = 'https://hanadatalake.siemens.com/siemens/MATSPEC/AWS/'

xsodata_hana_to_py = 'ODATA_CONNECTIONS.xsodata'
source_object = '/T_TC_PKG'

odata_url_eh0 = main_url_eh0 + xsodata_hana_to_py + source_object
odata_url_ehq = main_url_ehq + xsodata_hana_to_py + source_object
odata_url_eh1 = main_url_eh1 + xsodata_hana_to_py + source_object

# Write parameters
target_table = 'J_INSERT_T_SIMILARITY.xsjs'

write_similarity_eh0 = main_url_eh0 + target_table
write_similarity_ehq = main_url_ehq + target_table
write_similarity_eh1 = main_url_eh1 + target_table

# Print info
print("Working directory: " + os.getcwd())
print("User: " + user)
print("EH0 odata URL: " + odata_url_eh0)
print("EH0 target URL: " + write_similarity_eh0)
