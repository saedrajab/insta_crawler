import pandas as pd
import os
import numpy as np
import pickle

def remove_dup_columns(df):
    keep_names = set()
    unique_col_names = df.columns.unique()
    #keep_icols = list()
    for icol, name in enumerate(frame.columns):
         if name not in keep_names:
            keep_names.add(name)
            keep_icols.append(icol)  
    
    return frame.iloc[:, keep_icols]


def remove_dup_columns(df):
    keep_names = set()
    unique_col_names = df.columns.unique()
    #keep_icols = list()
    for icol, name in enumerate(frame.columns):
         if name not in keep_names:
            keep_names.add(name)
            keep_icols.append(icol)  
    
    return frame.iloc[:, keep_icols]

def which_col_to_take(df, col1,col2,datapath = None, filename = None, drop_column = True, verbose = 0 , threshold = 0.95):
    """
        function that decides which column to take if they are identical based on the amount of values that are not Null
        
    """
    N = len(df.loc[(~df[col1].isna()) & (~ df[col2].isna() )])
    check = sum(df[col1] == df[col2]) / N if N else 0
      
    if check > threshold:

        if sum(df[col1].isnull()) < sum(df[col2].isnull()):
            col_to_keep = col1
            if verbose > 0:
                print(col1 + " transfer to final since more non-NULL values")
            if drop_column:
                df.drop(columns = [col2], inplace = True)
            #j += 1

        else:
            #k = j
            col_to_keep = col2
            if verbose > 0:
                print(col2 + " transfer to final since more non-NULL values")
                
            if drop_column:
                df.drop(columns = [col1], inplace = True)
                
        if (datapath or filename):
            with open(filename, 'a') as out:
                split1 = col1.find("_")
                split2 = col2.find("_") 
                if col1[split1:].lower() == col2[split2:].lower(): 
                    var = "Columns " + col1 + " and " + col2 +  " have identical names."
                    out.write(var + '\n')
                
                var = "More than " + str(threshold) + " rows coincide in colums " + col1 + " and " + col2
                out.write(var + '\n')
                var = col_to_keep + " transfer to final since more non-NULL values"
    return df


def pattern_replacer(df, column, pattern_to_replace = None, pattern_to_take = None):
    """
            Function that replaces the string specified in pattern_to_replace (as list) with the correspondent values from 
            pattern_to_take.
        """
    if pattern_to_replace:
        for pattern in zip(pattern_to_replace,pattern_to_take):
            df[column].replace(pattern[0] ,pattern[1], inplace = True) 
            #df[column].replace(pattern[0] ,pattern[1]) 
    return df



    
def read_raw_rables(table, connection = None):
    """
        Fuunction for automatically collect all tables for specific materials
    """
        
    if not connection: 
        print("Please enter a valid connection (i.e. SQLAlchemy engine)")
        return table_dic
    
    else: 
        if table:    
           
            if table.rfind(r"-") > -1:
                table = "`" + table + "`"
                #print("New table name: " + table)
            if table[:3] in ("ihs","sex"):
                try:
                    df = pd.read_sql('select * from ' + table  ,  con = connection)
                    print("Dump of table " + table + " successful")
                except:
                    print("Dump of table " + table + " didn't succeed")
                    pass
        else: 
            print("No tables from IHS or SE found")
    return df



def clean_tables(df, fillna = None):
    """
        Fucntion that enhance perfromance by removing all NA rows are 
        before. Also if fillna is provided all NAN of the cols are replaced with a value
        
    """
    #print("Shape of " + df + " before cleaning: " + df.shape)
    df.dropna(axis = 1,thresh = 2, inplace = True)
    df.dropna(thresh = 2, inplace = True)
    
    if fillna: 
        df.fillna(fillna, inplace = True)
    #print("Shape of " + df + " after cleaning: " + df.shape)
    return df

def clean_raw_tables(raw_table,tablename, pattern_to_replace= None ,pattern_to_take = None, threshold_NaN = 0.95, log_filename = None):
    """
        Function for cleaning all tables containing to a specific material group one by one. 
        Inputs: 
            raw_table: raw_table
            pattern_to_replace: Pattern to replace in rows columnwise
            pattern_to_take: Pattern to take instead in rows columnwise
            threshold_table_length: Threshold, eg. ratio of rows in a tables compared to the longest table in the database. 
                Per default consider only tables that have at least 5 % or more rows. All others are not considered
            threshold_NaN: Threshold. If more than Threshold percent of all entries of a column are NaN drop the column as non-informative
            filename: Should a log file be written? Then enter a valid filename
    """
    #pattern_to_replace = ["", "N/A", "N/R"]
    #pattern_to_take = [np.nan, np.nan, np.nan]
    
    # Solution for gettting up the path found here: https://stackoverflow.com/questions/27844088/python-get-directory-two-levels-up/27844562
   
   
    logpath = os.path.join(os.path.dirname(os.getcwd()), "Logs")
    if not os.path.exists(logpath):
        os.makedirs(logpath)


    threshold = threshold_NaN

    #cleaned_table_dic = dict()

    if not log_filename: 


        # For details working with time format: https://docs.python.org/3/library/datetime.html#strftime-strptime-behavior
        now = datetime.now()
        print("No logfile is printed. Write filename to " + "Log_" + now.strftime('%Y_%m_%d_%H_%M_%S') +  ".txt" )
        log_filename = os.path.join(logpath, "Log_" + now.strftime('%Y_%m_%d_%H_%M_%S') +  ".txt")

    log_filename = os.path.join(logpath, log_filename)
    print("Logfile is printed to " + log_filename)

    with open(log_filename, 'w') as out:

        out.write("Begin cleansing of table " + tablename + "\n")
        df = raw_table.copy()
        if tablename[:3] == 'ihs': 
            _index = "objectId"
            # convert sting to float for easier joins
            df[_index] = df[_index].astype("int64")
        elif tablename[:3] == "sex": 
            _index  = "commId"
        else: 
            print("Table neither IHS or SE. No index created")


        col_to_check = df.columns.tolist()
        for col in col_to_check:
            df = pattern_replacer(df, col, pattern_to_replace, pattern_to_take)
            df[col].replace("\s+", np.nan, inplace = True)
            tol = sum(df[col].isnull())/len(df)
            if tol > threshold:
                df.drop(columns = [col], inplace = True)
                out.write("Column: " + col + "get dropped because of " + "{:.2%}".format(tol) + " Null values." + "\n")
            else: 
                out.write("Column: " + col + " has " + "{:.2%}".format(1 - tol) + " non-Null values." + "\n")

        df.set_index(_index, inplace = True)
        #df.set_index(_index, inplace = True)

    print("Cleansing table " + tablename + " successfull")

    return df


# Drop all rows withour content or with at least thresh non-NaN values. (this has to be discussed )
#%timeit 
#print("Unique keys in IHS before dropna: " + str(len(df_ihs.index.drop_duplicates())))
def row_cleaner(df, fillna = None):
    """
        Fucntion that enhance perfromance by removing all NA rows are 
        before. Also if fillna is provided all NAN of the cols are replaced with a value
        
    """
    df.dropna(axis = 1, how = "all", inplace = True)
    df.dropna(how = "all", inplace = True)
    df.sort_index(inplace = True)
    df.reset_index(inplace= True)
    df.drop_duplicates(keep = "last", inplace=True)
    if fillna: 
        df.fillna(fillna, inplace = True)
    return df

def _apply_df(df, agg_dict, groupByColumn):
    #df, agg_dict, groupByColumn = args
    return df.groupby(groupByColumn).agg(agg_dict)


def aggregate_by_column(df, cols,  groupByColumn, func  = "max", n_jobs = 1, backend = None ):
    """
        Fucntion that aggregates arbitrary cols of a dataframe by the groupby column. To enhance perfromance all NA rows are 
        dropped before. Also if fillna is provided all NAN of the cols are replaced with a value
        
    """
    agg_dict = dict((col,func) for col in cols)
    if n_jobs == 1:
        
        return _apply_df([df, agg_dict, groupByColumn])
    elif n_jobs != 1:
        
        
      #  pool = mp.Pool(processes=n_jobs)
        unique_index = np.array_split(df[groupByColumn].unique(), n_jobs)
        split_dfs = [df[df[groupByColumn].isin(unique_index[k])] for k in range(n_jobs)]

 #       result = pool.map(_apply_df, [(d, agg_dict, groupByColumn) for d in split_dfs])
        results = Parallel(n_jobs=n_jobs, verbose = 1,backend = backend)(delayed(_apply_df,)(df, agg_dict = agg_dict, groupByColumn = groupByColumn) for df in split_dfs)


#        pool.close()
        return pd.concat(results)
     
    #df.groupby(groupByColumn).agg(agg_dict)
    else: 
        print("Please enter a valid number of n_jobs. Return Dataframe")
        return df

def make_read_data_url(main_url, odata_point, source_object, statements = []):
    """
        Function to build easy to use odata url for reading data from HANA using odata service.
        See https://www.odata.org/documentation/odata-version-2-0/uri-conventions/
        input
            main_url = main_url 
            odata_point = is the name of the xsodata connection
            source_object = table or view to read from
            statements = list of filter statements to use. Currently every list item is combined using " and " operation
        output: 
            odata-url to read data from 
        
    """
    if len(statements) == 0: 
        return main_url + odata_point + source_object +"?$format=json"
    else: 
        state = " and ".join(w for w in statements)
        return main_url + odata_point + source_object +"?$format=json" + state  
    
def create_att_table(df, index_cols):
    """
        Function that create an attribute table out of the key value pair tables.
        inputs: 
            df = The dataframe to be transformed
            index_cols = index columns
    """
    
    df_tmp = df.set_index(index_cols)
    df_tmp = df_tmp[~df_tmp.index.duplicated(keep='last')]
    df_tmp2 = df_tmp.unstack()
    df_tmp2.columns = df_tmp2.columns.get_level_values(1)
    return clean_tables(df_tmp2)

def save_obj(obj, path, name ):
    """
        Saves any object as pickle file.
        Input: 
            dictionary: Name of the dictionary to be stored
            path: File path where to store the dictionary
            name: Name of the dicitonary
    """
      
    with open(path + name + '.pkl', 'wb') as f:
        pickle.dump(obj, f)
        
        
def load_obj(path, name):
    """
        Loads and returns any pickled object
        Input: 
            
            path: File path where to store the dictionary
            name: Name of the dicitonary
        Return: the loaded Dictionary
    """
    
    with open(path + name + '.pkl', 'rb') as f:
        return pickle.load(f)