def global_variables():
    global_dic = dict()
       
    global_dic["gid"] = "z000sypa"
    global_dic["dbnames"] = ["matspec_tmp", "matspec_attribute", "tmp"]
    return global_dic



import pandas as pd

def setup_pandas():
    options = {
        'display': {
            'max_columns': None,
            'max_colwidth': 50,
            'expand_frame_repr': False,  # Don't wrap to multiple pages
            'max_rows': 14,
            'max_seq_items': 150,         # Max length of printed sequence
            'precision': 4,
            'show_dimensions': False
        },
        'mode': {
            'chained_assignment': None   # Controls SettingWithCopyWarning
        }
    }

    for category, option in options.items():
        for op, value in option.items():
            pd.set_option(f'{category}.{op}', value)