import numpy as np
import os
import psutil
import traceback
import pandas as pd
import gc
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.pipeline import Pipeline, FeatureUnion
from sklearn.preprocessing import MinMaxScaler
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.neighbors import NearestNeighbors
from scipy import sparse
import re
import sys
import multiprocessing as mp
from joblib import Parallel, delayed, dump
import warnings
from timeit import time
import datetime
import seaborn as sns
import matplotlib.pyplot as plt
from nltk.stem import PorterStemmer, WordNetLemmatizer
from nltk import word_tokenize
import nltk
nltk.download('punkt')
import langid
from itertools import zip_longest
from collections import Counter
from itertools import cycle