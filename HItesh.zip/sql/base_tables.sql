-- SE
select 
a.partNumber,
max(a.commID) as commID,
max(a.manufacturer) as Manufacturer_SE_max,
min(a.manufacturer) as Manufacturer_SE_min,
max(a.partDescription) as Description_SE,
max(datasheet) as SE_Datasheet, 
max(a.onlineSupplierDatasheetURL) as Supplier_Datasheet,
max(taxonomyPath) as taxonomyPath,
max(estimatedYearsToEOL) as max_EOL_SE,
max(productImageLarge) as Image_large,
max( SUBSTRING_INDEX(SUBSTRING_INDEX(taxonomyPath, '>', 1), '>', -1)) as Category_SE,
max(case 
	when classificationId = 'EL050701' THEN 'el. Mech. Relay'
	when classificationId = 'EL050703' THEN 'Halbleiter Relais'
	when classificationId = 'EL010101' THEN 'Fixed Resistor'
	when classificationId = 'EL050802' THEN 'Control Switch (Schalter)'
	when classificationId = 'EL010202' THEN 'Capacitor'
	when classificationId = 'EL020101' THEN 'Zener/Reference/Suppr.Diodes'
	when classificationId = 'EL0205' THEN 'Thyristor'
	when classificationId = 'EL020601' THEN 'Bipolar Transistor'
	when classificationId = 'EL020602' THEN 'Transistor FET'
	when classificationId = 'EL0204' THEN 'Quartz/Quartz Oscillator'
	when classificationId = 'EL0511' THEN 'Fuse'
	when classificationId = 'EL0303' THEN 'LED'
	when classificationId = 'EL0304' THEN 'OptoCoupler'
	when classificationId = 'EL0401' THEN 'IC Analog Other '
	when classificationId = 'EL0404' THEN 'IC Functional Circuits'
	when classificationId = 'El0410' THEN 'IC Voltage Controller'
	when classificationId = 'EL0407' THEN 'IC-Operationsverstärker /Komparator'
	when classificationId = 'EL0502' THEN 'Reactor'
	when classificationId = 'EL0504' THEN 'Filter'
	when classificationId = 'EL0512' THEN 'Transformer'
	when classificationId = 'EL070501' THEN 'Connector on PCB'
	when classificationId = 'EL0406' THEN 'IC Logic Circuit'
	when classificationId = 'EL0411' THEN 'IC Memory'
	when classificationId = 'ME0101' THEN 'Screws'
	else classificationId
	end) as Category_TC,
    max(reach.cachedSource) as REACH_Article_SE,
    max(risk.lifecycleStage) as Life_Cycle_Stage_SE,
    max(risk.rohsRisk) as RoHS_Risk_SE,
    max(env.rohsStatus) as RoHS_Status_SE,
    max(env.chinaRoHSStatus) as China_RoHS_Status_SE,
    max(env.conflictMineralStatement) as Conflict_Mineral_SE,
    max(env.liveSupplierSource) as Live_SupplierSource_SE
from matspec_tmp_new.SeGetPartDetailsSummaryData a 
join matspec_tmp_new.SeGetPartDetailsLifeCycleData  b
	on a.commId = b.commId
join matspec_tmp_new.SeGetPartDetailsProductImage c
	on a.commId = c.commId
left join matspec_tmp_new.SeGetPartDetailsRiskData risk
    on risk.commId = a.commId
left join matspec_tmp_new.TcOrdClassifications x
	on a.partNumber = x.ordOrderDescription
left join matspec_tmp_new.SeGetPartDetailsEnvironmentalData env 
	on env.commId = a.commId
left join matspec_tmp_new.SeGetPartDetailsReachData reach
    on reach.commId = a.commId
where b.partStatus <> 'Obsolete'
group by a.partNumber


-- IHS 

select 
    manufacturerPartNumber as partNumber,
    max(parts.mfrName) as Manufacturer_IHS_max,
    min(parts.mfrName) as Manufacturer_IHS_min,
    max(parts.objectId) as objectId, 
    max(partDescription) as Description_IHS, 
    max(partType) as partType, 
    max(category) as category , 
    max(docUrl) as IHS_Datasheet,
    max(docTitle) as DocTitle,
    max(docs.pubDate) as pubDate,
    max(estimatedYteol) as max_EOL_IHS,
    max(lifecycleStage) as Life_Cycle_Stage_IHS,
    max(case 
        when classificationId = 'EL050701' THEN 'el. Mech. Relay'
        when classificationId = 'EL050703' THEN 'Halbleiter Relais'
        when classificationId = 'EL010101' THEN 'Fixed Resistor'
        when classificationId = 'EL050802' THEN 'Control Switch (Schalter)'
        when classificationId = 'EL010202' THEN 'Capacitor'
        when classificationId = 'EL020101' THEN 'Zener/Reference/Suppr.Diodes'
        when classificationId = 'EL0205' THEN 'Thyristor'
        when classificationId = 'EL020601' THEN 'Bipolar Transistor'
        when classificationId = 'EL020602' THEN 'Transistor FET'
        when classificationId = 'EL0204' THEN 'Quartz/Quartz Oscillator'
        when classificationId = 'EL0511' THEN 'Fuse'
        when classificationId = 'EL0303' THEN 'LED'
        when classificationId = 'EL0304' THEN 'OptoCoupler'
        when classificationId = 'EL0401' THEN 'IC Analog Other '
        when classificationId = 'EL0404' THEN 'IC Functional Circuits'
        when classificationId = 'El0410' THEN 'IC Voltage Controller'
        when classificationId = 'EL0407' THEN 'IC-Operationsverstärker /Komparator'
        when classificationId = 'EL0502' THEN 'Reactor'
        when classificationId = 'EL0504' THEN 'Filter'
        when classificationId = 'EL0512' THEN 'Transformer'
        when classificationId = 'EL070501' THEN 'Connector on PCB'
        when classificationId = 'EL0406' THEN 'IC Logic Circuit'
        when classificationId = 'EL0411' THEN 'IC Memory'
        when classificationId = 'ME0101' THEN 'Screws'
        else classificationId
        end) as Category_TC,
        max(REACH_Article) as REACH_Article_IHS
    from matspec_tmp_new.IhsParts parts
    left join (select * from matspec_tmp_new.IhsDoc a
            join (select objectId as o_id, max(pubDate) as LastDate from matspec_tmp_new.IhsDoc group by objectId) b
        on a.objectId = b.o_id
    and a.pubDate = b.LastDate
    where a.docType = 'Datasheet') docs
        on parts.objectId = docs.objectId
    left join (
        select 
            objectID, docUrl as REACH_Article, a.pubDate
        from matspec_tmp_new.IhsHazmat  a
        left join (select objectId as o_id, max(pubDate) as LastDate from matspec_tmp_new.IhsHazmat where docType = 'CoC-REACH' group by objectId) b
            on a.objectId = b.o_id
            and a.pubDate = b.LastDate
        where docType = 'CoC-REACH'
        ) haz
        on haz.objectId = parts.objectId
    left join matspec_tmp_new.TcOrdClassifications x
        on parts.manufacturerPartNumber = x.ordOrderDescription
    where partStatus <> 'Discontinued' 
    group by manufacturerPartNumber